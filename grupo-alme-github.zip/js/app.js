// Grupo Alme · lógica de la página (rutas con # y vistas)
const IMG={logo:"img/logo.jpg",club:"img/club.jpg",pink:"img/pink.jpg",bamboo:"img/bamboo.jpg",sushi:"img/sushi.jpg",lounge:"img/lounge.jpg",libs:"img/libs.jpg",moon:"img/moon.jpg"};
const $=s=>document.querySelector(s),app=$("#app"),nav=$("#nav"),sh=$("#sh");
const E=s=>encodeURIComponent(s);
function tog(o){nav.classList.toggle("o",o);sh.classList.toggle("o",o);$("#menu").setAttribute("aria-expanded",o)}
$("#menu").onclick=()=>tog(!nav.classList.contains("o"));sh.onclick=()=>tog(false);addEventListener("keydown",e=>{if(e.key==="Escape")tog(false)});
function go(h){location.hash=h}
function wire(){app.querySelectorAll("[data-g]").forEach(b=>b.onclick=()=>go(b.dataset.g))}
function landing(){
  const c=[["pink","t"],["club","w"],["bamboo","t"],["sushi",""],["lounge",""],["libs","t"],["moon","t"]];
  app.innerHTML="<section class=hero style=\"background-image:linear-gradient(rgba(5,5,6,.6),rgba(5,5,6,.92)),url("+IMG.club+")\"><img class=logo src='"+IMG.logo+"' alt='Logo de Grupo Alme'><h1 class=brand>GRUPO ALME</h1><p class=tag>Gastronomía y entretenimiento en México</p><div class=row2><button class='btn p' data-g=manual>Entrar al manual</button><button class=btn data-g=locales>Restaurantes y antros</button></div></section><section class=col><div class=grp style='text-align:center'>Nuestros espacios</div><div class=collage>"+c.map(x=>"<img class='"+x[1]+"' src='"+IMG[x[0]]+"' alt='Espacio de Grupo Alme' loading=lazy>").join("")+"</div></section>";
  wire();
}
function home(){
  let h="<h1>Manual de diseño de servicios</h1><p class=sub>Caso: Grupo Alme · Ciencia de los Servicios, O2026<br>Diego Emiliano Nava Pulido, Alejandro Castro, Aaron Sandoval Díaz y Emiliano Navarro Vargas</p><h2 style='margin-top:28px'>Índice</h2>",g="";
  P.forEach((p,i)=>{if(G[i]!==g){g=G[i];h+="<div class=grp>"+g+"</div>"}h+="<button class='it' data-g='p"+i+"'>"+p[0]+"<span>›</span></button>"});
  app.innerHTML=h;wire();
}
function page(i){
  const p=P[i];
  app.innerHTML="<button data-g=manual>← Índice</button><div class=sub style='margin-top:18px'>"+G[i]+"</div><h2>"+p[1]+"</h2>"+p[2]+"<div class=nv>"+(i>0?"<button data-g='p"+(i-1)+"'>← "+P[i-1][0]+"</button>":"<span></span>")+(i<P.length-1?"<button class='btn p' data-g='p"+(i+1)+"'>"+P[i+1][0]+" →</button>":"<span></span>")+"</div>";
  wire();
}
function locales(){
  let h="<h1>Restaurantes y antros</h1><p class=sub>Los 16 conceptos que aparecen en la página oficial de Grupo Alme.</p><div class=warn>Reservas especiales para artistas y personalidades: se solicitan directamente con el grupo en <a href=mailto:contacto@grupoalme.mx>contacto@grupoalme.mx</a>, indicando el concepto y la ciudad.</div><div class=grid>";
  V.forEach(v=>h+="<button class='card' data-g='r-"+v[0]+"'>"+v[1]+"<small>"+(v[2].length?v[2].join(" · "):"Ver detalles")+"</small></button>");
  app.innerHTML=h+"</div>";wire();
}
function local(s){
  const v=V.find(x=>x[0]===s);if(!v)return locales();
  const mp=c=>"https://www.google.com/maps/search/?api=1&query="+E(v[1]+" "+c),cs=v[2].length?v[2]:["Grupo Alme"];
  const b="<div class=row>"+cs.map(c=>"<a class='btn p' target=_blank rel=noopener href='"+mp(c)+"'>📍 Ubicación"+(cs.length>1?" · "+c:"")+"</a>").join("")+"<a class=btn target=_blank rel=noopener href='https://grupoalme.mx/"+v[3]+"'>Página oficial</a>"+(v[4]?"<a class=btn target=_blank rel=noopener href='https://www.instagram.com/"+v[4]+"'>Instagram</a>":"")+"</div>";
  app.innerHTML="<button data-g=locales>← Todos</button><div class=wm style='margin-top:16px'><img src='"+IMG.logo+"' alt='Grupo Alme'><div>"+v[1]+"</div><p class=sub style='text-align:center'>"+(v[2].length?v[2].join(" · "):"Grupo Alme")+"</p></div>"+b+
  "<dl><dt>Historia</dt><dd>"+(v[5]||"Aún sin completar. Consulta la página oficial del concepto.")+"</dd>"+
  "<dt>Reservaciones y contacto</dt><dd>Correo del grupo: <a href=mailto:contacto@grupoalme.mx>contacto@grupoalme.mx</a>"+(v[6]?"<br>"+v[6].join("<br>"):"<br>También puedes reservar desde la página oficial o el Instagram del concepto.")+"</dd>"+
  "<dt>Reservas especiales (artistas y personalidades)</dt><dd>Se solicitan escribiendo a <a href=mailto:contacto@grupoalme.mx>contacto@grupoalme.mx</a> e indicando el concepto y la ciudad.</dd>"+
  "<dt>Reseñas, estrellas y demanda</dt><dd>Consulta las reseñas, las estrellas y los “Horarios populares” (qué días y horas hay más gente) en la ficha de Google Maps, con el botón de Ubicación.</dd>"+
  "<dt>Reconocimientos</dt><dd>Sin datos verificados todavía.</dd></dl><div class=warn>Esta página no puede consultar reseñas ni horarios en vivo; por eso se ven en Google Maps.</div>";
  wire();
}
function route(){
  const h=location.hash.slice(1)||"inicio";tog(false);
  $("#n0").className=h==="inicio"?"on":"";$("#n1").className=h==="manual"||/^p\d+$/.test(h)?"on":"";$("#n2").className=h==="locales"||h.startsWith("r-")?"on":"";
  app.className=h==="inicio"?"wide":"";
  if(h==="locales")locales();else if(h.startsWith("r-"))local(h.slice(2));else if(/^p\d+$/.test(h)&&P[+h.slice(1)])page(+h.slice(1));else if(h==="manual")home();else landing();
  scrollTo(0,0);
}
addEventListener("hashchange",route);route();
